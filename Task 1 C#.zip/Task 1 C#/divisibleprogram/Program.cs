﻿using System;

namespace divisibleprogram
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number :");
            num = Convert.ToInt32(Console.ReadLine());
            if(num%5==0 && num%11==0)
            {
                Console.WriteLine("numbber divisible by 5 and 11 is =" + num);
            }
            else
            {
                Console.WriteLine("numbber is not divisible by 5 and 11  =" + num);
            }
        }
    }
}
