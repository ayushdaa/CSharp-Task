﻿using System;

namespace Area_of_an_Equilateral_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            float a;
            Console.WriteLine("Enter the Side");
            a = float.Parse(Console.ReadLine());
            double area;
            area = (1.73 * a * a) / 4;
            Console.WriteLine("Area of Equilateral Triangle = "+area);
        }
    }
}
