﻿using System;

namespace Average
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2, sum, avg;
            Console.Write("Enter two number to calculate avg :");
            num1 = Convert.ToDouble(Console.ReadLine());
            num2 = Convert.ToDouble(Console.ReadLine());
            sum = num1 + num2;
            avg = sum / 2;
            Console.Write("average of two numbers :" + avg);
        }
    }
}
