﻿using System;

namespace Area_Of_Right_Angled_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            float a,b,area;
            Console.WriteLine("Enter Hight value");
            a = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Base value");
            b = float.Parse(Console.ReadLine());
            area = (a * b) / 2;
            Console.WriteLine("Area Of Right Angled Triangle "+area);
        }
    }
}
