﻿using System;

namespace Multiplication_Table
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number :");
            num = Convert.ToInt32(Console.ReadLine());
            for(int i=1;i<=10;i++)
            { 
                Console.WriteLine("{0}*{1}={2} ",num,i,num*i);
            }
        }
    }
}
