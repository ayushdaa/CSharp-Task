﻿using System;
using System.Collections.Generic;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> d = new Dictionary<int, string>();
            d.Add(1, "Ayush");
            d.Add(2, "Akram");
            d.Add(3, "Rahul");
            d.Add(4, "Shubham");
            foreach (KeyValuePair<int, string> item in d)
            {
                Console.WriteLine(item.Key);
            }

            //Factorial();
            Console.ReadKey();
        }

        private static void Factorial()
        {
            int i, num, fact;
            Console.WriteLine("------- Find the factorial of a given number ------");
            Console.Write("Enter the Number : ");
            num = int.Parse(Console.ReadLine());
            fact = num;
            for (i = num - 1; i >= 1; i--)
            {
                fact = fact * i;
            }
            Console.WriteLine("Factorial of given number is : " + fact);
        }
    }
}
