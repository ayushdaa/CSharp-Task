﻿using System;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Average();
            AbsoluteValue();
            CompoundInterest();
            Cube();
            LeapYear();
            EvenOdd();
            EvenNumber();
            LargestOfTwoNumbers();
            LargestOfThreeNumbers();
            MultiplicationTable();
            Divisible();
            SimpleInterest();
            ArmstrongNumber();
            PrimeNumber();
            PrimeNumbersFrom1to100();
            AreaOfParallelogram();
            AreaOfTrapezoid();
            AreaOfRightAngledTriangle();
            AreaOfEquilateralTriangle();
            AreaOfRhombus();
            PerimeterOfRhombus();

            Console.ReadKey();
        }

        private static void PerimeterOfRhombus()
        {
            float a, perimeter;
            Console.Write("Enter side of Rhombus: ");
            a = float.Parse(Console.ReadLine());
            perimeter = 4 * a;
            Console.WriteLine("The perimeter of rhombus " +
                              "with side " + a + " is " + perimeter + ".");
        }

        private static void AreaOfRhombus()
        {
            double d1, d2, area;
            Console.WriteLine("Enter first Diagonal");
            d1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Second Diagonal");
            d2 = Convert.ToDouble(Console.ReadLine());
            area = (d1 * d2) / 2;
            Console.WriteLine("Area Of Rhombus is =" + area);
        }

        private static void AreaOfEquilateralTriangle()
        {
            float a;
            Console.WriteLine("Enter the Side");
            a = float.Parse(Console.ReadLine());
            double area;
            area = (1.73 * a * a) / 4;
            Console.WriteLine("Area of Equilateral Triangle = " + area);
        }

        private static void AreaOfRightAngledTriangle()
        {
            float a, b, area;
            Console.WriteLine("Enter Hight value");
            a = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Base value");
            b = float.Parse(Console.ReadLine());
            area = (a * b) / 2;
            Console.WriteLine("Area Of Right Angled Triangle " + area);
        }

        private static void AreaOfTrapezoid()
        {
            double a, b, h, area;
            Console.WriteLine("Enter First Base Value");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second Base Value");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Hight Value");
            h = double.Parse(Console.ReadLine());
            area = ((a + b) / 2) * h;
            Console.WriteLine("Area of Trapezoid " + area);
        }

        private static void AreaOfParallelogram()
        {
            double b, h, area;
            Console.WriteLine("Enter Base Value");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Hight Value");
            h = double.Parse(Console.ReadLine());
            area = b * h;
            Console.WriteLine("Area Of Parallelogram " + area);
        }

        private static void PrimeNumbersFrom1to100()
        {
            bool isPrime = true;
            Console.WriteLine("Prime Number From 1 to 100");
            int i, j;
            for (i = 2; i <= 100; i++)
            {
                for (j = 2; j <= 100; j++)
                {
                    if (i != j && i % j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    Console.WriteLine("\t" + i);
                }
                isPrime = true;
            }
        }

        private static void PrimeNumber()
        {
            int n, i, m = 0, flag = 0;
            Console.WriteLine("Enter Number to check Prinme");
            n = int.Parse(Console.ReadLine());
            m = n / 2;
            for (i = 2; i <= m; i++)
            {
                if (n % i == 0)
                {
                    Console.WriteLine("Number is not Prime");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
                Console.WriteLine("Number is Prime");
        }

        private static void ArmstrongNumber()
        {
            int num, r, sum = 0, temp;
            Console.WriteLine("Enter the number :");
            num = int.Parse(Console.ReadLine());
            temp = num;
            while (num > 0)
            {
                r = num % 10;
                sum = sum + (r * r * r);
                num = num / 10;
            }
            if (temp == sum)
            {
                Console.WriteLine("Armstrong Number");
            }
            else
            {
                Console.WriteLine("Not Armstrong Number");
            }
        }

        private static void SimpleInterest()
        {
            double si, principleamount, time, rate;
            Console.WriteLine("Enter principle amount :");
            principleamount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter time:");
            time = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter rate :");
            rate = Convert.ToDouble(Console.ReadLine());

            si = (principleamount * time * rate) / 100;
            Console.WriteLine("simple interest = " + si);
        }

        private static void Divisible()
        {
            int num;
            Console.WriteLine("Enter a number :");
            num = Convert.ToInt32(Console.ReadLine());
            if (num % 5 == 0 && num % 11 == 0)
            {
                Console.WriteLine("numbber divisible by 5 and 11 is =" + num);
            }
            else
            {
                Console.WriteLine("numbber is not divisible by 5 and 11  =" + num);
            }
        }

        private static void MultiplicationTable()
        {
            int num;
            Console.WriteLine("Enter a number :");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0}*{1}={2} ", num, i, num * i);
            }
        }

        private static void LargestOfThreeNumbers()
        {
            int num1, num2, num3;
            Console.WriteLine("Enter three numbers :");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            num3 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("largest number is :" + num1);

            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("largest number is " + num2);
            }
            else
            {
                Console.WriteLine("largest number is " + num3);
            }
        }

        private static void LargestOfTwoNumbers()
        {
            int num1, num2;
            Console.WriteLine("Enter two numbers :");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2)
            {
                Console.WriteLine("largest number is :" + num1);

            }
            else
            {
                Console.WriteLine("largest number is " + num2);
            }
        }

        private static void EvenNumber()
        {
            int num;
            Console.WriteLine("Enter the number :");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= num; i++)
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
        }

        private static void EvenOdd()
        {
            int num;
            Console.WriteLine("Enter an Number :");
            num = Convert.ToInt32(Console.ReadLine());
            if (num % 2 == 0)
            {
                Console.WriteLine("{0} is even number", num);
            }
            else
            {
                Console.WriteLine("{0} is odd number ", num);
            }
        }

        private static void LeapYear()
        {
            int year;
            Console.WriteLine("Enter the year :");
            year = Convert.ToInt32(Console.ReadLine());

            if (year % 400 == 0)
            {
                Console.WriteLine("{0} is a leap year.\n", year);

            }
            else if (year % 100 == 0)
            {
                Console.WriteLine("{0} is a leap year.\n", year);

            }
            else if (year % 4 == 0)
            {
                Console.WriteLine("{0} is a leap year.\n", year);

            }
            else
            {
                Console.WriteLine("{0} is not a leap year.\n", year);

            }
        }

        private static void Cube()
        {
            int num, cube;
            Console.WriteLine("Enter the number :");
            num = Convert.ToInt32(Console.ReadLine());
            cube = num * num * num;
            Console.WriteLine("Cube of the number :" + cube);
        }

        private static void CompoundInterest()
        {
            double ci, amount, p, r;
            int n, t;
            Console.WriteLine("Enter the principal balance = ");
            p = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter interest rate= ");
            r = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter compound frequency/year ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the year= ");
            t = Convert.ToInt32(Console.ReadLine());
            amount = p * Math.Pow((1 + r / (100 * n)), n * t);
            ci = amount - p;
            Console.WriteLine("Compound interest = " + Math.Round(ci, 2));
        }

        private static void AbsoluteValue()
        {
            int num;
            Console.WriteLine("Enter the number : ");
            num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("{0} Absolute value is : {1}", num, Math.Abs(num));
        }

        private static void Average()
        {
            double num1, num2, sum, avg;
            Console.WriteLine("Enter two number to calculate avg :");
            num1 = Convert.ToDouble(Console.ReadLine());
            num2 = Convert.ToDouble(Console.ReadLine());
            sum = num1 + num2;
            avg = sum / 2;
            Console.WriteLine("Average of two numbers :" + avg);
        }
    }
}
